package com.rohloffrobert.bonapp;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * This class will create the array adapter needed for the dropdown menus.
 *
 * Created by student on 5/3/2018.
 */

public class ObjectArrayAdapter extends ArrayAdapter<Recipes> {

    // declar ArrayList of items
    private ArrayList<Recipes> objects;

    /**
     * This method set the objects, resources, and context of the array adapter.
     *
     * @param context
     * @param resource
     * @param objects
     */
    public ObjectArrayAdapter(@NonNull Context context, int resource, ArrayList<Recipes> objects) {
        super(context, resource, objects);
        this.objects = objects;

    }

    /**
     * This method will get the view.
     *
     * @param position
     * @param convertView
     * @param parent
     * @return
     */
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        // assign the view we are converting to a local variable
        View view = convertView;

        // Check to see if view is null.  If so, we have to inflate the view
        // "inflate" means to render or show the view
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.list_layout, null);
        }

        /*
            Recall that the variable position is sent in as an argument to this method

            The variable simply refers to the position of the current object on the list.
            The ArrayAdapter iterate through the list we sent it

            versionObject refers to the current PlatformVersion object
         */
        Recipes recipe = objects.get(position);

        if (recipe != null) {
            //obtain a reference to widgets in the defined layout "wire up the widgets from detail_line"
            // note:  view.  which ties it to detail_line
            TextView mRecipeDate = (TextView) view.findViewById(R.id.recipeDate);
            TextView mRecipeName = (TextView) view.findViewById(R.id.recipeName);

            if (mRecipeDate != null) {
                mRecipeDate.setText(recipe.getDate());
            }
            if (mRecipeName != null) {
                mRecipeName.setText(recipe.getRecipeName());
            }
        }

        // the view (my custom detail_line with loaded data) returned to our Activity
        return view;

        //return super.getView(position, convertView, parent);
    }
}