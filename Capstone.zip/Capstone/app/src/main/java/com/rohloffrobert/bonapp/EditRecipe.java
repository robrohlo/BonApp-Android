package com.rohloffrobert.bonapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Created by student on 5/3/2018.
 */

public class EditRecipe extends AppCompatActivity {

    Button mConfirm;
    Button mCancel;
    EditText mName;
    EditText mDate;
    EditText mInstruction;
    Recipes recipe;
    ArrayList<Recipes> recipes;
    int position;

    /**
     * This will allow you to edit a recipe
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent = getIntent();
        recipes = intent.getParcelableArrayListExtra("recipeArray");
        recipe =  intent.getParcelableExtra("recipe");
        position = intent.getIntExtra("position", 0);

        mName = (EditText) findViewById(R.id.recipeName);
        mName.setText(recipe.getRecipeName());
        mDate = (EditText) findViewById(R.id.recipeDate);
        mDate.setText(recipe.getDate());
        mInstruction = (EditText) findViewById(R.id.instructions);
        mInstruction.setText(recipe.getDescription());

        mConfirm = (Button) findViewById(R.id.confirm);
        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                recipe.setRecipeName(mName.getText().toString());
                recipe.setDate(mDate.getText().toString());
                recipe.setDescription(mInstruction.getText().toString());

                recipes.set(position, recipe);

                Intent intent = new Intent(EditRecipe.this, VaultActivity.class);
                intent.putExtra("recipeArray", recipes);
                startActivity(intent);
            }
        });

            mCancel = (Button) findViewById(R.id.cancel);
            mCancel.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(EditRecipe.this, VaultActivity.class);
                    intent.putExtra("recipeArray", recipes);
                    startActivity(intent);
                }
            });
        }
    }

