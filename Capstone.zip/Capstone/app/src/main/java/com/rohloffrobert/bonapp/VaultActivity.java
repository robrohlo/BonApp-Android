package com.rohloffrobert.bonapp;

import android.content.Intent;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * This is the homescreen for the vault activity.
 *
 * Created by Rob on 5/7/2018.
 */
public class VaultActivity extends AppCompatActivity {

    private static final String ARRAY_KEY = "array_key";

    private TextView mMessage;
    private ListView mListView;
    private ArrayList<Recipes> recipes;
    ObjectArrayAdapter mArrayAdapter;
    FloatingActionButton mAddNew;

    /**
     * Sets the save instance state.
     *
     * @param savedInstanceState
     */
    @Override
    protected void onSaveInstanceState(Bundle savedInstanceState) {

        savedInstanceState.putParcelableArrayList(ARRAY_KEY, recipes);

        super.onSaveInstanceState(savedInstanceState);
    }

    /**
     * Restores the save instance state
     *
     * @param savedInstanceState
     */
    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        recipes = savedInstanceState.getParcelableArrayList(ARRAY_KEY);
    }

    /**
     * The oncreate method
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vault);
        Intent intent = getIntent();

        if (intent.getExtras() != null) {
            recipes = intent.getParcelableArrayListExtra("recipeArray");
        } else {
            recipes = new ArrayList<Recipes>();
        }

        mMessage = (TextView) findViewById(R.id.emptyList);
        mListView = (ListView) findViewById(R.id.list);

        mListView.setEmptyView(mMessage);

        //addRecipe();

        mArrayAdapter = new ObjectArrayAdapter(this, R.layout.list_layout, recipes);

        mListView.setAdapter(mArrayAdapter);

        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            /**
             * Pass the intent on clicking a list item.
             *
             * @param parent
             * @param view
             * @param position
             * @param id
             */
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(VaultActivity.this, EditRecipe.class);
                intent.putExtra("recipe", recipes.get(position));
                intent.putExtra("recipeArray", recipes);
                intent.putExtra("position", position);
                startActivityForResult(intent, 1);
            }
        });

        mAddNew = (FloatingActionButton) findViewById(R.id.fab);

        /**
         * Starts a new recipe.
         *
         */
        mAddNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
              Intent intent = new Intent(VaultActivity.this, NewRecipe.class);
                intent.putExtra("recipeArray", recipes);
              startActivity(intent);
            }
        });

    }
}
