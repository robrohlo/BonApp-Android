package com.rohloffrobert.bonapp;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

/**
 * Class that will convert units.
 *
 * Created by Rob on 5/7/2018.
 */
public class ConverterActivity extends AppCompatActivity {

    Button mConvert;
    Spinner mUnitTo;
    Spinner mUnitFrom;
    EditText mAmountFrom;
    TextView mResult;
    String[] unit_array;

    /**
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_converter);

        mConvert = (Button) findViewById(R.id.convert);
        mUnitFrom = (Spinner) findViewById(R.id.unitSelectorFrom);
        mUnitTo = (Spinner) findViewById(R.id.unitSelectorTo);
        mAmountFrom = (EditText) findViewById(R.id.amountFrom);
        mResult = (TextView) findViewById(R.id.result);

        unit_array = getResources().getStringArray(R.array.measurements);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,R.array.measurements,
                android.R.layout.simple_spinner_item);

        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        mUnitTo.setAdapter(adapter);
        mUnitFrom.setAdapter(adapter);

        mConvert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int from = mUnitFrom.getSelectedItemPosition();
                int to = mUnitTo.getSelectedItemPosition();
                String enteredAmount = mAmountFrom.getText().toString();
                int enteredInt = Integer.parseInt(enteredAmount);
                double conversionResult;
                String resultString;

                if (from == 0 && to == 1) {
                    conversionResult = (enteredInt * 0.33);
                    resultString = String.format("%.2f", conversionResult);
                    mResult.setText(resultString + " " + mUnitTo.getSelectedItem());
                }
            }
        });


    }
}
