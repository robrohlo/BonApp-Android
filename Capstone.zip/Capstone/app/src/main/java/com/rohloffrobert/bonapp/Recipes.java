package com.rohloffrobert.bonapp;

import android.os.Parcel;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;

/**
 * This is the information class for the recipes
 *
 * Created by student on 5/2/2018.
 */
public class Recipes extends AppCompatActivity implements Parcelable {
    String recipeName;
    String date;
    String description;

    /**
     * Getter for the recipe name
     *
     * @return
     */
    public String getRecipeName() {
        return recipeName;
    }

    /**
     *Setter for the recipe name
     *
     * @param recipeName
     */
    public void setRecipeName(String recipeName) {
        this.recipeName = recipeName;
    }

    /**
     *getter for the date
     *
     * @return
     */
    public String getDate() {
        return date;
    }

    /**
     * setter fro the date
     *
     * @param date
     */
    public void setDate(String date) {
        this.date = date;
    }

    /**
     *getter for the description
     *
     * @return
     */
    public String getDescription() {
        return description;
    }

    /**
     * Setter for the description.
     *
     * @param description
     */
    public void setDescription(String description) {
        this.description = description;
    }

    /**
     * Describes the parcel contents.
     *
     * @return
     */
    @Override
    public int describeContents() {
        return 0;
    }

    /**
     * Write to the parcel
     *
     * @param dest
     * @param flags
     */
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.recipeName);
        dest.writeString(this.date);
        dest.writeString(this.description);
    }

    /**
     * Constructor for the recipe.
     *
     */
    public Recipes() {
    }

    /**
     * Constructor for the parcel recipe.
     *
     * @param in
     */
    protected Recipes(Parcel in) {
        this.recipeName = in.readString();
        this.date = in.readString();
        this.description = in.readString();
    }

    /**
     * Creates the parcel.
     *
     */
    public static final Parcelable.Creator<Recipes> CREATOR = new Parcelable.Creator<Recipes>() {
        @Override
        public Recipes createFromParcel(Parcel source) {
            return new Recipes(source);
        }

        @Override
        public Recipes[] newArray(int size) {
            return new Recipes[size];
        }
    };
}
