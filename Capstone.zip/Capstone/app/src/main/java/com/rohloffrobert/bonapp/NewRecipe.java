package com.rohloffrobert.bonapp;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Creates a new recipe.
 *
 * Created by Rob on 5/7/2018.
 */

public class NewRecipe extends AppCompatActivity {

    Button mConfirm;
    Button mCancel;
    EditText mName;
    EditText mDate;
    EditText mInstruction;
    Recipes recipe;
    ArrayList<Recipes> recipes;

    /**
     * This method will create a new recipe.
     *
     * @param savedInstanceState
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent = getIntent();
        recipes = intent.getParcelableArrayListExtra("recipeArray");

        recipe = new Recipes();

        mName = (EditText) findViewById(R.id.recipeName);
        mDate = (EditText) findViewById(R.id.recipeDate);
        mInstruction = (EditText) findViewById(R.id.instructions);

        mConfirm = (Button) findViewById(R.id.confirm);
        mConfirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                recipe.setRecipeName(mName.getText().toString());
                recipe.setDate(mDate.getText().toString());
                recipe.setDescription(mInstruction.getText().toString());

                recipes.add(recipe);

                Intent intent = new Intent(NewRecipe.this, VaultActivity.class);
                intent.putExtra("recipeArray", recipes);
                startActivity(intent);
            }
        });

        mCancel = (Button) findViewById(R.id.cancel);
        mCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(NewRecipe.this, VaultActivity.class);
                intent.putExtra("recipeArray", recipes);
                startActivity(intent);
            }
        });
    }
}
